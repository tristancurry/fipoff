     ...laxxes fonts...

This font is (C) 1996, made by
Lasse Hedegaard, Denmark

This font is a part of three
free fonts, which all can be
downloaded at

http://fergusons.dk/fonts/

It's free of use, but be kind
and mail me with your comments

Thanks,
Lasse Hedegaard

laxxe@fergusons.dk